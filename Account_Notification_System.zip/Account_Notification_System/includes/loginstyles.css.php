<?php
/**
 * Created by PhpStorm.
 * User: PC
 * Date: 5/8/2019
 * Time: 1:11 PM
 */




 header('Content-type: text/css');


?>

.center_div{

    margin: 0 auto;
    margin-top:12em;

}



#submit-button{
    margin-bottom: 15px;
}

.bg-primary {
    padding:1em;
    border: 1px solid #0275d8;
    border-top-left-radius:5px;
    border-top-right-radius:5px;



}
#loginform {
    margin:2em;
    margin-top:2.5em;
    border-bottom-left-radius:5px;
    border-bottom-right-radius:5px;

}

#loginform button {
    margin-top:1.5em;
}
}
#loginform {
    margin:2em;
    margin-top:4em;


}
.hide {
    display:none;
}


.shadow-lg {
    border-bottom-left-radius:5px;
    border-bottom-right-radius:5px;
}
.bg-primary a:hover {
    color: #ffffff; text-decoration: underline !important;
}

.input-group {
    margin-top: 0;
}
#signupform {
    margin:0;
    padding:0;

}





.signuperror {
    color:red;
    font-weight: bold;
    font-size: xx-large;
}



#checkBox {
    margin:1em;
}

button{
    margin-left:1em;
}


h1, h2 {
    text-align: center;
}
nav li {
    margin-top:20px;
}


#signupbox input{
    margin-left:0.5em;

}
#signupbox label {
    padding-left: 20px;
}

.nav-bar text {
    float:right;
}


